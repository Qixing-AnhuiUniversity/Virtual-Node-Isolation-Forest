"Extended isolated forest functions"
__author__ = 'Matias Carrasco Kind && Qi Xing && Zi-Dong Zhou'
import numpy as np
from scipy.stats import multivariate_normal
import random as rn
import pandas as pd
from pandas import DataFrame
from sklearn import metrics
import time
import eif_vnif as iso_eif_vnif
import eif as iso_eif
import iso_forest as iso_if
import vnif as iso_vnif
import HS_Tree as iso_HS
import HS_Tree_vnif as iso_HS_vnif
from sklearn import svm



#X2=pd.read_csv('Twitter_volume_AAPL_100.csv')

# X2=pd.read_csv('arrhythmia_data.csv')
# X2_norm=np.array(X2)
X2=pd.read_csv('arrhythmia_data_test.csv')
X2_norm=np.array(X2[1:1000])
X2_norm=(X2_norm-X2_norm.mean())/(X2_norm.max()-X2_norm.min())
#X2_norm0 = (X2.T[0]-X2.T[0].min())/(X2.T[0].max()-X2.T[0].min()) #normalization
#X2_norm1 = (X2.T[1]-X2.T[1].min())/(X2.T[1].max()-X2.T[1].min()) #normalization
#X2_norm2 = (X2.T[2]-X2.T[2].min())/(X2.T[2].max()-X2.T[2].min()) #normalization
#X2_norm3 = (X2.T[3]-X2.T[3].min())/(X2.T[3].max()-X2.T[3].min()) #normalization
#X2_norm4 = (X2.T[1]-X2.T[1].min())/(X2.T[4].max()-X2.T[4].min()) #normalization
#X2_norm5 = (X2.T[2]-X2.T[2].min())/(X2.T[5].max()-X2.T[5].min()) #normalization
#X2_norm  = np.c_[X2_norm0,X2_norm1,X2_norm2,X2_norm3,X2_norm4,X2_norm5]

X1=pd.read_csv('arrhythmia_data.csv')
X1_norm=np.array(X1)
X1_norm=(X1_norm-X1_norm.mean())/(X2_norm.max()-X2_norm.min())
#X1_norm0 = (X1.T[0]-X1.T[0].min())/(X1.T[0].max()-X1.T[0].min()) #normalization
#X1_norm1 = (X1.T[1]-X1.T[1].min())/(X1.T[1].max()-X1.T[1].min()) #normalization
#X1_norm2 = (X1.T[2]-X1.T[2].min())/(X1.T[2].max()-X1.T[2].min()) #normalization
#X1_norm3 = (X1.T[3]-X1.T[3].min())/(X1.T[3].max()-X1.T[3].min()) #normalization
#X1_norm4 = (X1.T[1]-X1.T[1].min())/(X1.T[4].max()-X1.T[4].min()) #normalization
#X1_norm5 = (X1.T[2]-X1.T[2].min())/(X1.T[5].max()-X1.T[5].min()) #normalization
#X1_norm  = np.c_[X1_norm0,X1_norm1,X1_norm2,X1_norm3,X1_norm4,X1_norm5]



# ann
# X2=pd.read_csv('ann_thyroid_6000.csv')
# X2=np.array([X2.x1,X2.x2,X2.x3,X2.x4]).T
# X2_norm0 = (X2.T[0]-X2.T[0].min())/(X2.T[0].max()-X2.T[0].min())
# X2_norm1 = (X2.T[1]-X2.T[1].min())/(X2.T[1].max()-X2.T[1].min())
# X2_norm2 = (X2.T[2]-X2.T[2].min())/(X2.T[2].max()-X2.T[2].min())
# X2_norm3 = (X2.T[3]-X2.T[3].min())/(X2.T[3].max()-X2.T[3].min())
# X2_norm  = np.c_[X2_norm0,X2_norm1,X2_norm2,X2_norm3]
#
# X1=pd.read_csv('ann_thyroid_1.csv')
# X1=np.array([X1.x1,X1.x2,X1.x3,X1.x4]).T
# X1_norm0 = (X1.T[0]-X2.T[0].min())/(X2.T[0].max()-X2.T[0].min())
# X1_norm1 = (X1.T[1]-X2.T[1].min())/(X2.T[1].max()-X2.T[1].min())
# X1_norm2 = (X1.T[2]-X2.T[2].min())/(X2.T[2].max()-X2.T[2].min())
# X1_norm3 = (X1.T[3]-X2.T[3].min())/(X2.T[3].max()-X2.T[3].min())
# X1_norm  = np.c_[X1_norm0,X1_norm1,X1_norm2,X1_norm3]






#setting
Nobjs = X2_norm.shape[0]                                               #
Nobjs1 = X1_norm.shape[0]                                              #
ntrees=200
sample = 256
S_ = np.zeros(Nobjs1)
S_vnif = np.zeros(Nobjs1)
S_if = np.zeros(Nobjs1)
S_HS = np.zeros(Nobjs1)
S_HS_vnif = np.zeros(Nobjs1)
score_outlier = np.zeros(50)
score_normal = np.zeros(50)
c = iso_if.c_factor(sample)
# setting finished



# if
time_start = time.time()
CT = []
for i in range(ntrees):
    ix = rn.sample(range(Nobjs),sample)
    X_p = X2_norm[ix]                                                              #
    limit = 10
    C_if=iso_if.iTree(X_p,0,limit)
    CT.append(C_if)
for i in range(Nobjs1):
    h_temp = 0
    for j in range(ntrees):
        h_temp += iso_if.PathFactor(X1_norm[i],CT[j]).path*1.01                 #
    Eh = h_temp/ntrees
    S_if[i] = 2.0**(-Eh/c)
time_end = time.time()
print ('if totally cost ',time_end-time_start)
# if finished

# vnif
time_start = time.time()
CT = []
for i in range(ntrees):
    ix = rn.sample(range(Nobjs),sample)
    X_p = X2_norm[ix]                                                              #
    limit = 10
    C_if=iso_vnif.iTree(X_p,0,limit)
    CT.append(C_if)
for i in range(Nobjs1):
    h_temp = 0
    for j in range(ntrees):
        h_temp += iso_vnif.PathFactor(X1_norm[i],CT[j]).path*1.01                 #
    Eh = h_temp/ntrees
    S_vnif[i] = 2.0**(-Eh/c)
time_end = time.time()
print ('vnif totally cost ',time_end-time_start)
# vnif finished



# OCSVM
time_start = time.time()
clf = svm.OneClassSVM(nu=0.1, kernel="rbf", gamma=0.1)
clf.fit(X2_norm)
y_predsvm = clf.predict(X1_norm)
#svm_score = clf.decision_function(X2_Norm)
svm_score = clf.score_samples(X1_norm)
#svm_score_pd = DataFrame(-svm_score/100+1)

#svm_score_pd.to_csv('svm_score_samples.csv')
#y_pred_test = clf.predict(X_test)
#y_pred_outliers = clf.predict(X_outliers)
#n_error = y_pred[y_pred == -1].size
#n_error_test = y_pred_test[y_pred_test == -1].size
#n_error_outliers = y_pred_outliers[y_pred_outliers == 1].size
time_end = time.time()
# OCSVM finished
svm_score_pd = DataFrame(svm_score,columns=['svm_score'])
S_if_pd = DataFrame(S_if,columns=['if_score'])
S_vnif_pd = DataFrame(S_vnif,columns=['vnif_score'])


occupancy_score = pd.concat([svm_score_pd,S_if_pd,S_vnif_pd],axis=1)
occupancy_score.to_csv('arrhythmia_score.csv')                                #

#Y1 = pd.read_csv('Twitter_volume_AAPL.csv')
Y1 = pd.read_csv('arrhythmia_label.csv')
Y2 = pd.read_csv('arrhythmia_score.csv')
label = np.array(Y1)
svm_score = np.array(Y2.svm_score)
if_score = np.array(Y2.if_score)
vnif_score = np.array(Y2.vnif_score)

fpr1,tpr1,thresholds = metrics.roc_curve(label,svm_score,pos_label=0)
fpr2,tpr2,thresholds = metrics.roc_curve(label,if_score,pos_label=1)
fpr3,tpr3,thresholds = metrics.roc_curve(label,vnif_score,pos_label=1)


auc1=metrics.auc(fpr1,tpr1)
auc2=metrics.auc(fpr2,tpr2)
auc3=metrics.auc(fpr3,tpr3)
print('svm',auc1)
print('if',auc2)
print('vnif',auc3)

roc1=pd.DataFrame(fpr1)
roc2=pd.DataFrame(tpr1)
roc3=pd.DataFrame(fpr2)
roc4=pd.DataFrame(tpr2)
roc5=pd.DataFrame(fpr3)
roc6=pd.DataFrame(tpr3)

roc = pd.concat([roc1,roc2,roc3,roc4,roc5,roc6],axis=1)
roc.to_csv('smtp_roc.csv')